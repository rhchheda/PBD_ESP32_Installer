@echo off
REM Double-click launcher for students - runs the PowerShell installer
REM with the correct execution policy. This window stays open so any
REM early error (before the elevated window opens, or if elevation is
REM cancelled) is visible instead of the window flashing shut.
echo Starting Project Clinic setup...
echo A Windows "User Account Control" prompt will appear next - click Yes.
echo.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0Install-Project-Clinic-Setup.ps1"
echo.
echo ============================================
echo Setup script has exited. If a dashboard window
echo did not appear, check the message above for errors.
echo ============================================
pause
