#requires -Version 5.1
<#
    Project Clinic, KLE-C-SHInE - Student Machine Setup - Windows
    ------------------------------------------------------------
    Installs, with a live progress dashboard:
      1. Arduino IDE
      2. arduino-cli (headless - installs the ESP32 board core)
      3. ESP32 board package, Xtensa toolchain only (target: DOIT
         ESP32 DEVKIT V1). arduino-cli has no per-tool install flag,
         so the esp32:esp32 package still downloads its RISC-V
         toolchain (esp32:esp-rv32) too - this script removes that
         toolchain folder immediately afterwards since the DOIT V1
         never uses it, saving ~90+ MB of disk space it would
         otherwise occupy permanently.
      4. CP210x (Silicon Labs) USB-to-UART driver
      5. CH210x (WCH CH340/CH341) USB-to-UART driver
    Verifies each component afterwards, then shows a branded result
    dialog with the actual time taken.

    ARCHITECTURE
    ------------------------------------------------------------
    The UI thread runs Application.Run() normally - Windows' native
    message pump handles minimize/restore/drag/close correctly, with
    no manual DoEvents() polling anywhere (that was the cause of the
    window becoming unresponsive after minimizing in an earlier
    version of this script).

    All install work runs on a background runspace. The background
    scriptblock and the UI thread share exactly two objects, both
    passed in via AddArgument (safe - real shared .NET objects, not
    scriptblock closures, which was a bug in an earlier attempt at
    this rewrite):
      - a ConcurrentQueue the background side enqueues progress
        messages onto, and a WinForms Timer on the UI thread drains
        every 200ms to update the dashboard;
      - a one-element array used as a mutable "cancel requested"
        flag, set by the form's FormClosing event and checked by the
        background scriptblock between steps, so closing the window
        actually stops further work instead of orphaning it.

    Pre-flight: free space on the cache drive is checked against a
    configurable minimum before anything downloads. If insufficient,
    the script stops immediately with a clear message, rather than
    failing midway through a large extraction (which can leave
    partially-written, locked files behind that break the next run).
    ------------------------------------------------------------
#>

# ---------- 0. Self-elevate to Administrator ----------
$ErrorActionPreference = 'Stop'
if (-not ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) {
    $scriptPath = $MyInvocation.MyCommand.Definition
    try {
        Start-Process powershell -ArgumentList "-NoProfile -ExecutionPolicy Bypass -File `"$scriptPath`"" -Verb RunAs
    } catch {
        Write-Host ""
        Write-Host "Administrator permission was not granted, so setup cannot continue."
        Write-Host "Please run this again and click 'Yes' on the permission prompt."
        Write-Host ""
        Read-Host "Press Enter to close this window"
    }
    exit
}

Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$ScriptRoot = Split-Path -Parent $MyInvocation.MyCommand.Definition
$ConfigPath = Join-Path $ScriptRoot 'config.json'

$MinFreeSpaceGB = 3.0

$cfg = Get-Content $ConfigPath -Raw | ConvertFrom-Json

# Log file starts on the temp path of whichever drive Windows itself
# considers "the temp drive" - usually C:. This exists purely for
# logging and works even if we relocate everything else below.
$InitialLogDir = Join-Path $env:TEMP 'project-clinic-setup'
New-Item -ItemType Directory -Path $InitialLogDir -Force | Out-Null
$LogFile = Join-Path $InitialLogDir 'install-log.txt'

function Write-InstallLog {
    param([string]$Message)
    $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Message
    Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
}

# ---------- Pre-flight: pick an install drive with enough free space ----------
# Prefer the system drive (where Windows itself is installed) if it has
# enough room - keeping everything on one drive is simplest and what
# most lab PCs will have anyway. If not, automatically fall back to
# whichever other fixed, writable drive has the most free space. USB
# drives (DriveType 2) are excluded since they can be unplugged mid-
# install; only fixed local disks (DriveType 3) are considered.
$systemDriveLetter = $env:SystemDrive.TrimEnd(':')
$allFixedDrives = Get-CimInstance Win32_LogicalDisk -Filter "DriveType=3" |
    Select-Object DeviceID, @{N='FreeGB';E={[Math]::Round($_.FreeSpace / 1GB, 2)}}

$systemDrive = $allFixedDrives | Where-Object { $_.DeviceID.TrimEnd(':') -eq $systemDriveLetter }
$bestOtherDrive = $allFixedDrives |
    Where-Object { $_.DeviceID.TrimEnd(':') -ne $systemDriveLetter } |
    Sort-Object FreeGB -Descending | Select-Object -First 1

Write-InstallLog "Drive scan: system drive $($systemDrive.DeviceID) has $($systemDrive.FreeGB) GB free."
if ($bestOtherDrive) {
    Write-InstallLog "Best alternative drive: $($bestOtherDrive.DeviceID) has $($bestOtherDrive.FreeGB) GB free."
}

if ($systemDrive.FreeGB -ge $MinFreeSpaceGB) {
    $InstallDriveLetter = $systemDrive.DeviceID.TrimEnd(':')
    $UsedFallbackDrive = $false
}
elseif ($bestOtherDrive -and $bestOtherDrive.FreeGB -ge $MinFreeSpaceGB) {
    $InstallDriveLetter = $bestOtherDrive.DeviceID.TrimEnd(':')
    $UsedFallbackDrive = $true
    Write-InstallLog "System drive ${systemDriveLetter}: is short on space - installing Arduino IDE and ESP32 board files to ${InstallDriveLetter}: instead."
}
else {
    $largestFreeGB = ($allFixedDrives | Sort-Object FreeGB -Descending | Select-Object -First 1).FreeGB
    [System.Windows.Forms.MessageBox]::Show(
        "None of this computer's drives have at least $MinFreeSpaceGB GB free " +
        "(largest available: $largestFreeGB GB).`n`n" +
        "The Arduino IDE, ESP32 board files and USB drivers need this much room " +
        "to install reliably. Please free up disk space on any drive (Disk " +
        "Cleanup, uninstall unused apps, empty Recycle Bin) and run this setup again.",
        "$($cfg.InstituteName) - Not Enough Disk Space",
        'OK',
        [System.Windows.Forms.MessageBoxIcon]::Warning
    ) | Out-Null
    Write-InstallLog "Aborted: no drive has $MinFreeSpaceGB GB free."
    exit 1
}

# CacheDir (our downloaded installers) and the ESP32 toolchain data
# folder both move to the chosen drive. Windows USB drivers always
# install into the fixed driver store on the system drive regardless
# of this choice - that's a Windows constraint, not something any
# script can redirect, but driver installers are only a few MB so
# this doesn't affect the disk-space decision either way.
$CacheDir = "${InstallDriveLetter}:\Project-Clinic-Setup\Cache"
$WorkDir  = "${InstallDriveLetter}:\Project-Clinic-Setup\Work"
$ArduinoIdeInstallDir = "${InstallDriveLetter}:\Project-Clinic-Setup\Arduino IDE"
$ArduinoDataDir       = "${InstallDriveLetter}:\Project-Clinic-Setup\Arduino15"

# Detect a prior run before touching anything. A previous partial or
# complete install left in place can mix stale files with the new
# bundle-based ESP32 install (Expand-Archive -Force overwrites matching
# files but won't remove ones the new bundle doesn't include), so rather
# than silently layering on top of it, we ask once and then wipe clean.
$priorIdeFound  = Test-Path (Join-Path $ArduinoIdeInstallDir 'Arduino IDE.exe')
$priorCoreFound = Test-Path (Join-Path $ArduinoDataDir 'packages\esp32')
if ($priorIdeFound -or $priorCoreFound) {
    $foundParts = @()
    if ($priorIdeFound)  { $foundParts += 'Arduino IDE' }
    if ($priorCoreFound) { $foundParts += 'ESP32 board files' }
    Write-InstallLog "Prior installation detected: $($foundParts -join ', ')."

    $choice = [System.Windows.Forms.MessageBox]::Show(
        "A previous Project Clinic setup was found on this machine ($($foundParts -join ', ')).`n`n" +
        "Continuing will remove it and install everything fresh, to avoid mixing old and new files. " +
        "This does not affect your Arduino sketches saved elsewhere.`n`n" +
        "Continue and reinstall fresh?",
        "$($cfg.InstituteName) - Previous Setup Found",
        [System.Windows.Forms.MessageBoxButtons]::YesNo,
        [System.Windows.Forms.MessageBoxIcon]::Warning
    )
    if ($choice -eq [System.Windows.Forms.DialogResult]::Yes) {
        Write-InstallLog "User chose to remove prior installation and reinstall fresh."
        foreach ($oldPath in @($ArduinoIdeInstallDir, $ArduinoDataDir)) {
            if (Test-Path $oldPath) {
                Remove-Item -Path $oldPath -Recurse -Force -ErrorAction SilentlyContinue
                Write-InstallLog "Removed $oldPath"
            }
        }
    } else {
        Write-InstallLog "User declined to reinstall over an existing setup. Exiting without changes."
        exit 0
    }
}

New-Item -ItemType Directory -Path $WorkDir -Force | Out-Null
New-Item -ItemType Directory -Path $CacheDir -Force | Out-Null
foreach ($sub in 'ArduinoIDE','ArduinoCLI','Drivers','Logo') {
    New-Item -ItemType Directory -Path (Join-Path $CacheDir $sub) -Force | Out-Null
}

if ($UsedFallbackDrive) {
    Write-InstallLog "Using fallback drive ${InstallDriveLetter}: for Cache=$CacheDir, ArduinoData=$ArduinoDataDir"
}

$Steps = @(
    'Arduino IDE',
    'arduino-cli',
    'ESP32 board package',
    'CP210x USB driver',
    'CH210x USB driver',
    'Verifying installation'
)

# Shared thread-safe queue: background scriptblock -> UI thread
$ProgressQueue = [System.Collections.Concurrent.ConcurrentQueue[object]]::new()

# Shared cancellation flag: UI thread (on window close) -> background.
# A one-element array is used because PowerShell arrays are passed by
# reference, so both sides observe the same mutable cell.
$CancelFlag = ,$false

# ============================================================
# Dashboard controls (UI thread only)
# ============================================================
$dashForm    = New-Object System.Windows.Forms.Form
$stepLabels  = @{}
$overallBar  = $null
$statusLabel = $null
$timeLabel   = $null
$footerLabel = $null
$StartTime   = Get-Date

# Spinner shown next to whichever step is currently active - keeps the
# dashboard visibly alive during long steps (downloads, silent installs)
# instead of sitting on a static ">" with only the detail text changing.
$script:spinnerFrames   = @('|', '/', '-', '\')
$script:spinnerIndex    = 0
$script:activeStepName  = $null
$script:activeStepDetail = ''

function Build-Dashboard {
    param([string]$Title, [string]$LogoPath, [string]$SubtitleText = 'Preparing your machine for embedded development')

    $dashForm.Text = $Title
    $dashForm.Size = New-Object System.Drawing.Size(560, 570)
    $dashForm.StartPosition = 'CenterScreen'
    $dashForm.FormBorderStyle = 'FixedDialog'
    $dashForm.MaximizeBox = $false
    $dashForm.MinimizeBox = $true
    $dashForm.BackColor = [System.Drawing.Color]::White

    $formWidth = 560
    $y = 15
    if ($LogoPath -and (Test-Path $LogoPath)) {
        try {
            $logoSize = 84
            $pic = New-Object System.Windows.Forms.PictureBox
            $pic.Image = [System.Drawing.Image]::FromFile($LogoPath)
            $pic.SizeMode = 'Zoom'
            $pic.Size = New-Object System.Drawing.Size($logoSize, $logoSize)
            $pic.Location = New-Object System.Drawing.Point((($formWidth - $logoSize) / 2), $y)
            $dashForm.Controls.Add($pic)
        } catch {}
    }

    $headingY = $y + 92
    $heading = New-Object System.Windows.Forms.Label
    $heading.Text = $Title
    $heading.Font = New-Object System.Drawing.Font('Segoe UI', 11, [System.Drawing.FontStyle]::Bold)
    $heading.TextAlign = 'MiddleCenter'
    $heading.Location = New-Object System.Drawing.Point(0, $headingY)
    $heading.Size = New-Object System.Drawing.Size($formWidth, 26)
    $heading.AutoSize = $false
    $dashForm.Controls.Add($heading)

    $subY = $headingY + 28
    $sub = New-Object System.Windows.Forms.Label
    $sub.Text = $SubtitleText
    $sub.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $sub.ForeColor = [System.Drawing.Color]::Gray
    $sub.TextAlign = 'MiddleCenter'
    $sub.Location = New-Object System.Drawing.Point(0, $subY)
    $sub.Size = New-Object System.Drawing.Size($formWidth, 20)
    $dashForm.Controls.Add($sub)

    $listY = $subY + 32
    foreach ($step in $Steps) {
        $row = New-Object System.Windows.Forms.Label
        $row.Text = "  o   $step"
        $row.Font = New-Object System.Drawing.Font('Segoe UI', 10)
        $row.ForeColor = [System.Drawing.Color]::DimGray
        $row.Location = New-Object System.Drawing.Point(30, $listY)
        $row.Size = New-Object System.Drawing.Size(500, 24)
        $dashForm.Controls.Add($row)
        $script:stepLabels[$step] = $row
        $listY += 30
    }

    $barY = $listY + 10
    $script:overallBar = New-Object System.Windows.Forms.ProgressBar
    $script:overallBar.Location = New-Object System.Drawing.Point(30, $barY)
    $script:overallBar.Size = New-Object System.Drawing.Size(500, 22)
    $script:overallBar.Minimum = 0
    $script:overallBar.Maximum = $Steps.Count
    $dashForm.Controls.Add($script:overallBar)

    $statusY = $listY + 38
    $script:statusLabel = New-Object System.Windows.Forms.Label
    $script:statusLabel.Text = 'Starting...'
    $script:statusLabel.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $script:statusLabel.ForeColor = [System.Drawing.Color]::Gray
    $script:statusLabel.Location = New-Object System.Drawing.Point(30, $statusY)
    $script:statusLabel.Size = New-Object System.Drawing.Size(500, 20)
    $dashForm.Controls.Add($script:statusLabel)

    $timeY = $listY + 60
    $script:timeLabel = New-Object System.Windows.Forms.Label
    $script:timeLabel.Text = 'Elapsed: 0s   |   Estimated total: calculating...'
    $script:timeLabel.Font = New-Object System.Drawing.Font('Segoe UI', 9)
    $script:timeLabel.ForeColor = [System.Drawing.Color]::Gray
    $script:timeLabel.Location = New-Object System.Drawing.Point(30, $timeY)
    $script:timeLabel.Size = New-Object System.Drawing.Size(500, 20)
    $dashForm.Controls.Add($script:timeLabel)

    $footerY = $timeY + 35
    $footer = New-Object System.Windows.Forms.Label
    $footer.Text = "Made with $([char]0x2764) ~rhc " + [char]0x00B7 + " Project Clinic, KLE-C-SHInE"
    $footer.Font = New-Object System.Drawing.Font('Segoe UI', 8.5)
    $footer.ForeColor = [System.Drawing.Color]::Gray
    $footer.TextAlign = 'MiddleCenter'
    $footer.Location = New-Object System.Drawing.Point(30, $footerY)
    $footer.Size = New-Object System.Drawing.Size(500, 20)
    $dashForm.Controls.Add($footer)
    $script:footerLabel = $footer
}

function Set-StepUi {
    param([string]$Step, [string]$State, [string]$Detail = '')
    $lbl = $stepLabels[$Step]
    if (-not $lbl) { return }
    switch ($State) {
        'active' {
            $script:activeStepName   = $Step
            $script:activeStepDetail = $Detail
            $glyph = $script:spinnerFrames[$script:spinnerIndex]
            $lbl.Text = "  $glyph   $Step $Detail"; $lbl.ForeColor = [System.Drawing.Color]::RoyalBlue
        }
        'done'   {
            if ($script:activeStepName -eq $Step) { $script:activeStepName = $null }
            $lbl.Text = "  v   $Step";         $lbl.ForeColor = [System.Drawing.Color]::SeaGreen
        }
        'failed' {
            if ($script:activeStepName -eq $Step) { $script:activeStepName = $null }
            $lbl.Text = "  x   $Step";         $lbl.ForeColor = [System.Drawing.Color]::Firebrick
        }
        default  { $lbl.Text = "  o   $Step";         $lbl.ForeColor = [System.Drawing.Color]::DimGray }
    }
}

function Show-ResultDialog {
    param(
        [string]$Title, [string]$Message, [string]$LogoPath,
        [System.Windows.Forms.MessageBoxIcon]$Icon = [System.Windows.Forms.MessageBoxIcon]::Information
    )
    $form = New-Object System.Windows.Forms.Form
    $form.Text = $Title
    $form.Size = New-Object System.Drawing.Size(440, 350)
    $form.StartPosition = 'CenterScreen'
    $form.FormBorderStyle = 'FixedDialog'
    $form.MaximizeBox = $false
    $form.MinimizeBox = $false
    $form.TopMost = $true

    if ($LogoPath -and (Test-Path $LogoPath)) {
        try {
            $pic = New-Object System.Windows.Forms.PictureBox
            $pic.Image = [System.Drawing.Image]::FromFile($LogoPath)
            $pic.SizeMode = 'Zoom'
            $pic.Size = New-Object System.Drawing.Size(100, 100)
            $pic.Location = New-Object System.Drawing.Point(170, 15)
            $form.Controls.Add($pic)
        } catch {}
    }

    $label = New-Object System.Windows.Forms.Label
    $label.Text = $Message
    $label.TextAlign = 'MiddleCenter'
    $label.Location = New-Object System.Drawing.Point(20, 130)
    $label.Size = New-Object System.Drawing.Size(390, 110)
    $label.Font = New-Object System.Drawing.Font('Segoe UI', 10)
    $form.Controls.Add($label)

    $btn = New-Object System.Windows.Forms.Button
    $btn.Text = 'OK'
    $btn.Location = New-Object System.Drawing.Point(170, 245)
    $btn.Size = New-Object System.Drawing.Size(100, 32)
    $btn.DialogResult = 'OK'
    $form.Controls.Add($btn)
    $form.AcceptButton = $btn

    $footer = New-Object System.Windows.Forms.Label
    $footer.Text = "Made with $([char]0x2764) ~rhc " + [char]0x00B7 + " Project Clinic, KLE-C-SHInE"
    $footer.Font = New-Object System.Drawing.Font('Segoe UI', 8)
    $footer.ForeColor = [System.Drawing.Color]::Gray
    $footer.TextAlign = 'MiddleCenter'
    $footer.Location = New-Object System.Drawing.Point(20, 285)
    $footer.Size = New-Object System.Drawing.Size(390, 20)
    $form.Controls.Add($footer)

    [void]$form.ShowDialog()
}

# ============================================================
# Background scriptblock. This is a real [scriptblock] object,
# passed directly to AddScript() - not stringified - so its
# param() block correctly receives the arguments given to
# AddArgument() below. This is the fix for the earlier version's
# broken closure/stringification attempt.
# ============================================================
$BackgroundScript = {
    param($cfg, $CacheDir, $WorkDir, $LogFile, $ProgressQueue, $CancelFlag, $ArduinoIdeInstallDir, $ArduinoDataDir)

    function Write-InstallLog {
        param([string]$Message)
        $line = "[{0}] {1}" -f (Get-Date -Format 'HH:mm:ss'), $Message
        Add-Content -Path $LogFile -Value $line -ErrorAction SilentlyContinue
    }
    function Post-Progress {
        param([string]$Type, [string]$Step = '', [string]$State = '', [string]$Detail = '', [string]$Message = '')
        $ProgressQueue.Enqueue([pscustomobject]@{ Type=$Type; Step=$Step; State=$State; Detail=$Detail; Message=$Message })
    }
    function Test-Cancelled { return [bool]$CancelFlag[0] }

    function Get-CachedFile {
        param([string]$Url, [string]$CacheSubfolder, [string]$FileName, [string]$ExpectedSha256 = '')
        $destPath = Join-Path (Join-Path $CacheDir $CacheSubfolder) $FileName
        if (Test-Path $destPath) {
            $valid = $true
            if ($ExpectedSha256) {
                $actual = (Get-FileHash -Path $destPath -Algorithm SHA256).Hash
                $valid = ($actual -ieq $ExpectedSha256)
                if (-not $valid) { Write-InstallLog "Cache hash mismatch for $FileName - will re-download" }
            }
            if ($valid) { Write-InstallLog "Using cached file: $destPath"; return $destPath }
        }
        Write-InstallLog "Downloading $Url"
        Invoke-WebRequest -Uri $Url -OutFile $destPath -UseBasicParsing
        if ($ExpectedSha256) {
            $actual = (Get-FileHash -Path $destPath -Algorithm SHA256).Hash
            if ($actual -ine $ExpectedSha256) { throw "Downloaded file $FileName failed SHA256 verification." }
        }
        Write-InstallLog "Cached at $destPath"
        return $destPath
    }

    function Install-DriverPackage {
        param([string]$DownloadedPath, [string]$ExtractDir, [string]$PreferredExeNamePattern)
        $bytes = [System.IO.File]::ReadAllBytes($DownloadedPath)[0..1]
        $isZip = ($bytes[0] -eq 0x50 -and $bytes[1] -eq 0x4B)
        if (-not $isZip) { return $DownloadedPath }

        Write-InstallLog "$DownloadedPath is a ZIP archive - extracting before install."

        # Clear leftovers from a previous run BEFORE extracting - a prior
        # failed/interrupted attempt can leave a locked or
        # partially-written file that Expand-Archive can't overwrite,
        # which caused the earlier "Access is denied" error. If it's
        # still locked (e.g. antivirus mid-scan), fall back to a fresh
        # folder rather than failing outright.
        if (Test-Path $ExtractDir) {
            try {
                Remove-Item -Path $ExtractDir -Recurse -Force -ErrorAction Stop
            } catch {
                Write-InstallLog "Could not fully clear $ExtractDir (possibly locked by antivirus scan) - using a fresh folder instead."
                $ExtractDir = "$ExtractDir-$(Get-Random)"
            }
        }
        New-Item -ItemType Directory -Path $ExtractDir -Force | Out-Null

        $zipRenamed = Join-Path $ExtractDir 'source.zip'
        Copy-Item -Path $DownloadedPath -Destination $zipRenamed -Force
        Expand-Archive -Path $zipRenamed -DestinationPath $ExtractDir -Force

        $exe = Get-ChildItem -Path $ExtractDir -Recurse -Filter '*.exe' |
               Where-Object { $_.Name -match $PreferredExeNamePattern } | Select-Object -First 1
        if (-not $exe) { $exe = Get-ChildItem -Path $ExtractDir -Recurse -Filter '*.exe' | Select-Object -First 1 }
        if (-not $exe) { throw "No installer .exe found inside archive: $DownloadedPath" }
        Write-InstallLog "Using extracted installer: $($exe.FullName)"
        return $exe.FullName
    }

    function Install-SilentExe {
        param([string]$Path, [string]$StepName)
        $silentArgSets = @('/S', '/s /v"/qn"', '/quiet', '/VERYSILENT')
        foreach ($argSet in $silentArgSets) {
            try {
                $proc = Start-Process -FilePath $Path -ArgumentList $argSet -PassThru -WindowStyle Hidden
            } catch { continue }

            $dots = 0
            while (-not $proc.HasExited) {
                if (Test-Cancelled) {
                    Write-InstallLog "${StepName}: cancellation requested - stopping installer process."
                    try { $proc.Kill() } catch {}
                    return -999
                }
                Start-Sleep -Milliseconds 400
                $dots = ($dots + 1) % 4
                Post-Progress -Type 'step' -Step $StepName -State 'active' -Detail ('(installing' + ('.' * $dots) + ')')
            }
            Write-InstallLog "${StepName}: installer ran with args '$argSet', exit code $($proc.ExitCode)"
            return $proc.ExitCode
        }
        Write-InstallLog "${StepName}: no silent argument set worked - installer may need manual completion."
        return -1
    }

    try {
        $logoLocal = Join-Path $CacheDir 'Logo\logo.png'
        try {
            if (-not (Test-Path $logoLocal)) {
                Invoke-WebRequest -Uri $cfg.LogoUrl -OutFile $logoLocal -UseBasicParsing
            }
        } catch { Write-InstallLog "Logo not available: $_" }

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }
        Post-Progress -Type 'step' -Step 'Arduino IDE' -State 'active' -Detail '(downloading)'
        $ideInstaller = Get-CachedFile -Url $cfg.ArduinoIdeUrl -CacheSubfolder 'ArduinoIDE' -FileName 'arduino-ide-installer.exe' -ExpectedSha256 $cfg.ArduinoIdeSha256
        Post-Progress -Type 'step' -Step 'Arduino IDE' -State 'active' -Detail '(installing)'
        # /D=<path> sets the NSIS installer's target directory - must be
        # the last argument with no quotes/spaces around it. This is what
        # actually redirects Arduino IDE off the system drive when a
        # fallback drive was chosen due to low disk space upstream.
        try {
            $ideArgs = "/S /D=$ArduinoIdeInstallDir"
            $ideProc = Start-Process -FilePath $ideInstaller -ArgumentList $ideArgs -PassThru -WindowStyle Hidden
            while (-not $ideProc.HasExited) {
                if (Test-Cancelled) { try { $ideProc.Kill() } catch {}; Post-Progress -Type 'cancelled'; return }
                Start-Sleep -Milliseconds 400
            }
            Write-InstallLog "Arduino IDE installed to $ArduinoIdeInstallDir (exit code $($ideProc.ExitCode))"
        } catch {
            Write-InstallLog "Custom-path install failed ($_), falling back to default silent install."
            Install-SilentExe -Path $ideInstaller -StepName 'Arduino IDE' | Out-Null
        }
        Post-Progress -Type 'step' -Step 'Arduino IDE' -State 'done'
        Post-Progress -Type 'advance' -Message 'Arduino IDE installed.'

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }
        Post-Progress -Type 'step' -Step 'arduino-cli' -State 'active' -Detail '(downloading)'
        $cliZip = Get-CachedFile -Url $cfg.ArduinoCliUrl -CacheSubfolder 'ArduinoCLI' -FileName 'arduino-cli.zip' -ExpectedSha256 $cfg.ArduinoCliSha256
        $cliDir = Join-Path $WorkDir 'arduino-cli'
        Expand-Archive -Path $cliZip -DestinationPath $cliDir -Force
        $cliExe = Join-Path $cliDir 'arduino-cli.exe'
        Post-Progress -Type 'step' -Step 'arduino-cli' -State 'done'
        Post-Progress -Type 'advance' -Message 'arduino-cli ready.'

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }

        $env:ARDUINO_DIRECTORIES_DATA = $ArduinoDataDir
        New-Item -ItemType Directory -Path $ArduinoDataDir -Force | Out-Null
        Write-InstallLog "arduino-cli data directory set to $ArduinoDataDir"

        & $cliExe config init --overwrite | Out-Null
        & $cliExe config add board_manager.additional_urls $cfg.Esp32BoardsManagerUrl | Out-Null
        # Small JSON index only (a few hundred KB) - keeps arduino-cli's
        # board manager metadata in sync even though the actual platform
        # files below come from our prebuilt bundle, not "core install".
        & $cliExe core update-index | Out-Null

        # InstallScope picks which prebuilt bundle to fetch instead of
        # running "core install esp32:esp32", which always downloads every
        # chip variant's -libs package (h2/p4/s2/s3/c2/c3/c5/c6 + RISC-V
        # toolchains) regardless of target board - that's what made this
        # step slow. Both bundles are just a zipped, ready-to-use copy of
        # ArduinoDataDir\packages\esp32 from a machine that already ran a
        # full install once; arduino-cli discovers platforms by scanning
        # this folder structure, so dropping it in place works the same
        # as installing through the board manager.
        # "DoitV1Only" (default) = pruned to the Xtensa esp32 toolchain
        # only, matching the manual prune step used previously.
        # "Full" = every variant kept, for machines that may need other
        # ESP32 boards later.
        $useFullScope = ($cfg.InstallScope -eq 'Full')
        $bundleUrl    = if ($useFullScope) { $cfg.Esp32CoreBundleUrl_Full }    else { $cfg.Esp32CoreBundleUrl_Lite }
        $bundleSha    = if ($useFullScope) { $cfg.Esp32CoreBundleSha256_Full } else { $cfg.Esp32CoreBundleSha256_Lite }
        $bundleLabel  = if ($useFullScope) { 'full' } else { 'DOIT V1 lite' }

        Post-Progress -Type 'step' -Step 'ESP32 board package' -State 'active' -Detail "(downloading $bundleLabel bundle)"
        $bundleZip = Get-CachedFile -Url $bundleUrl -CacheSubfolder 'Esp32CoreBundle' -FileName "esp32-core-$($bundleLabel -replace ' ','-').zip" -ExpectedSha256 $bundleSha

        Post-Progress -Type 'step' -Step 'ESP32 board package' -State 'active' -Detail '(extracting)'
        $packagesDir = Join-Path $ArduinoDataDir 'packages'
        New-Item -ItemType Directory -Path $packagesDir -Force | Out-Null
        Expand-Archive -Path $bundleZip -DestinationPath $packagesDir -Force
        Write-InstallLog "Extracted $bundleLabel ESP32 core bundle into $packagesDir"

        Post-Progress -Type 'step' -Step 'ESP32 board package' -State 'done'
        Post-Progress -Type 'advance' -Message 'ESP32 board package installed.'

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }
        Post-Progress -Type 'step' -Step 'CP210x USB driver' -State 'active' -Detail '(downloading)'
        $cp210xRaw = Get-CachedFile -Url $cfg.Cp210xDriverUrl -CacheSubfolder 'Drivers' -FileName 'CP210xVCPInstaller.exe' -ExpectedSha256 $cfg.Cp210xSha256
        $cp210xInstaller = Install-DriverPackage -DownloadedPath $cp210xRaw -ExtractDir (Join-Path $WorkDir 'cp210x-extracted') -PreferredExeNamePattern 'CP210x.*\.exe$'
        Post-Progress -Type 'step' -Step 'CP210x USB driver' -State 'active' -Detail '(installing)'
        $cp210xExit = Install-SilentExe -Path $cp210xInstaller -StepName 'CP210x USB driver'
        if ($cp210xExit -ne 0) { Write-InstallLog "CP210x installer exit code $cp210xExit - will confirm in verification." }
        Post-Progress -Type 'step' -Step 'CP210x USB driver' -State 'done'
        Post-Progress -Type 'advance' -Message 'CP210x driver installed.'

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }
        Post-Progress -Type 'step' -Step 'CH210x USB driver' -State 'active' -Detail '(downloading)'
        $ch210xRaw = Get-CachedFile -Url $cfg.Ch210xDriverUrl -CacheSubfolder 'Drivers' -FileName 'CH341SER.EXE' -ExpectedSha256 $cfg.Ch210xSha256
        $ch210xInstaller = Install-DriverPackage -DownloadedPath $ch210xRaw -ExtractDir (Join-Path $WorkDir 'ch210x-extracted') -PreferredExeNamePattern 'CH341SER.*\.exe$|SETUP\.exe$'
        Post-Progress -Type 'step' -Step 'CH210x USB driver' -State 'active' -Detail '(installing)'
        $ch210xExit = Install-SilentExe -Path $ch210xInstaller -StepName 'CH210x USB driver'
        if ($ch210xExit -ne 0) { Write-InstallLog "CH210x installer exit code $ch210xExit - will confirm in verification." }
        Post-Progress -Type 'step' -Step 'CH210x USB driver' -State 'done'
        Post-Progress -Type 'advance' -Message 'CH210x driver installed.'

        if (Test-Cancelled) { Post-Progress -Type 'cancelled'; return }
        Post-Progress -Type 'step' -Step 'Verifying installation' -State 'active'
        $checks = @()
        $ideExe = Get-ChildItem -Path $ArduinoIdeInstallDir,"$env:LOCALAPPDATA\Programs\Arduino IDE","$env:ProgramFiles\Arduino IDE" -Filter 'Arduino IDE.exe' -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1
        $checks += [pscustomobject]@{ Item = 'Arduino IDE'; Ok = [bool]$ideExe }

        $coreList = & $cliExe core list 2>$null
        $checks += [pscustomobject]@{ Item = 'ESP32 board package'; Ok = [bool]($coreList -match 'esp32:esp32') }

        $boardListing = & $cliExe board listall 2>$null
        $checks += [pscustomobject]@{ Item = 'DOIT ESP32 DEVKIT V1 target'; Ok = [bool]($boardListing -match 'esp32doit-devkit-v1') }

        $driverEnum = pnputil /enum-drivers
        $checks += [pscustomobject]@{ Item = 'CP210x USB driver'; Ok = [bool]($driverEnum | Select-String -Pattern 'CP210x|silabs|Silicon Labs' -Quiet) }
        $checks += [pscustomobject]@{ Item = 'CH210x USB driver'; Ok = [bool]($driverEnum | Select-String -Pattern 'CH341|CH340|wch' -Quiet) }

        foreach ($c in $checks) {
            Write-InstallLog ("Check: {0} -> {1}" -f $c.Item, $(if ($c.Ok) {'OK'} else {'MISSING'}))
        }
        $failed = $checks | Where-Object { -not $_.Ok }

        if ($failed.Count -eq 0) {
            Post-Progress -Type 'step' -Step 'Verifying installation' -State 'done'
        } else {
            Post-Progress -Type 'step' -Step 'Verifying installation' -State 'failed'
        }
        Post-Progress -Type 'advance' -Message 'Verification complete.'

        $failedNames = ($failed | ForEach-Object { $_.Item }) -join '|'
        Post-Progress -Type 'done' -Message $failedNames
    }
    catch {
        Write-InstallLog "ERROR: $_"
        Post-Progress -Type 'error' -Message "$_"
    }
}

# ============================================================
# Launch background runspace
# ============================================================
$runspace = [runspacefactory]::CreateRunspace()
$runspace.Open()
$posh = [powershell]::Create()
$posh.Runspace = $runspace

[void]$posh.AddScript($BackgroundScript)
[void]$posh.AddArgument($cfg)
[void]$posh.AddArgument($CacheDir)
[void]$posh.AddArgument($WorkDir)
[void]$posh.AddArgument($LogFile)
[void]$posh.AddArgument($ProgressQueue)
[void]$posh.AddArgument($CancelFlag)
[void]$posh.AddArgument($ArduinoIdeInstallDir)
[void]$posh.AddArgument($ArduinoDataDir)

$asyncResult = $posh.BeginInvoke()

# ============================================================
# UI-thread timer: drains the progress queue and updates the
# dashboard. Only place dashboard controls are touched.
# ============================================================
$logoLocalForUi = Join-Path $CacheDir 'Logo\logo.png'
$dashboardSubtitle = if ($UsedFallbackDrive) {
    "Installing to ${InstallDriveLetter}: (system drive was low on space)"
} else {
    'Preparing your machine for embedded development'
}
Build-Dashboard -Title "$($cfg.InstituteName) Setup" -LogoPath $logoLocalForUi -SubtitleText $dashboardSubtitle

# Signal cancellation to the background scriptblock when the window
# is closed, instead of leaving it running orphaned.
$dashForm.Add_FormClosing({
    $CancelFlag[0] = $true
})

$uiTimer = New-Object System.Windows.Forms.Timer
$uiTimer.Interval = 200
$script:heartOn = $false

$uiTimer.Add_Tick({
    $script:heartOn = -not $script:heartOn
    if ($footerLabel) {
        $footerLabel.ForeColor = if ($script:heartOn) { [System.Drawing.Color]::Crimson } else { [System.Drawing.Color]::Gray }
    }

    # Advance and redraw the busy spinner on whichever step is active,
    # independent of the queue below - this is what keeps it animating
    # smoothly through long silent downloads/installs with no new messages.
    $script:spinnerIndex = ($script:spinnerIndex + 1) % $script:spinnerFrames.Count
    if ($script:activeStepName -and $stepLabels.ContainsKey($script:activeStepName)) {
        $glyph = $script:spinnerFrames[$script:spinnerIndex]
        $stepLabels[$script:activeStepName].Text = "  $glyph   $script:activeStepName $script:activeStepDetail"
    }

    $elapsed = (Get-Date) - $StartTime
    $elapsedStr = "{0}m {1}s" -f [int]$elapsed.TotalMinutes, $elapsed.Seconds
    $doneSteps = $overallBar.Value
    if ($doneSteps -gt 0) {
        $avgPerStep = $elapsed.TotalSeconds / $doneSteps
        $remaining = [Math]::Max(($avgPerStep * ($Steps.Count - $doneSteps)), 0)
        $etaStr = "{0}m {1}s remaining" -f [int]($remaining / 60), [int]($remaining % 60)
    } else {
        $etaStr = "calculating..."
    }
    $timeLabel.Text = "Elapsed: $elapsedStr   |   $etaStr"

    $msg = $null
    while ($ProgressQueue.TryDequeue([ref]$msg)) {
        switch ($msg.Type) {
            'step' {
                Set-StepUi -Step $msg.Step -State $msg.State -Detail $msg.Detail
            }
            'advance' {
                $overallBar.Value = [Math]::Min($overallBar.Value + 1, $overallBar.Maximum)
                $statusLabel.Text = $msg.Message
            }
            'cancelled' {
                $uiTimer.Stop()
                $dashForm.Close()
            }
            'error' {
                $uiTimer.Stop()
                $dashForm.Hide()
                [System.Windows.Forms.MessageBox]::Show(
                    "Setup failed. Please show this log to your lab instructor:`n`n$LogFile`n`nError: $($msg.Message)",
                    "$($cfg.InstituteName) - Setup Failed",
                    'OK', [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
                $dashForm.Close()
            }
            'done' {
                $uiTimer.Stop()
                $totalElapsed = (Get-Date) - $StartTime
                $elapsedStrFinal = "{0} min {1} sec" -f [int]$totalElapsed.TotalMinutes, $totalElapsed.Seconds
                $dashForm.Hide()

                if ([string]::IsNullOrEmpty($msg.Message)) {
                    Show-ResultDialog -Title "$($cfg.InstituteName) - Setup Complete" `
                        -Message "$($cfg.SuccessMessage)`n`nTotal time taken: $elapsedStrFinal" `
                        -LogoPath $logoLocalForUi

                    try {
                        $ideExePath = Join-Path $ArduinoIdeInstallDir 'Arduino IDE.exe'
                        if (Test-Path $ideExePath) {
                            Write-InstallLog "Launching Arduino IDE for the student: $ideExePath"
                            Start-Process -FilePath $ideExePath
                        }
                    } catch { Write-InstallLog "Could not auto-launch Arduino IDE (non-fatal): $_" }
                } else {
                    $missingList = ($msg.Message -split '\|') -join "`n - "
                    Show-ResultDialog -Title "$($cfg.InstituteName) - Setup Incomplete" `
                        -Message "Most components installed in $elapsedStrFinal, but these need attention:`n - $missingList`n`nPlease contact your lab instructor. Log: $LogFile" `
                        -LogoPath $logoLocalForUi -Icon ([System.Windows.Forms.MessageBoxIcon]::Warning)
                }
                $dashForm.Close()
            }
        }
    }
})
$uiTimer.Start()

[System.Windows.Forms.Application]::Run($dashForm)

try {
    $null = $posh.EndInvoke($asyncResult)
} catch {}
try {
    $posh.Dispose()
    $runspace.Close()
} catch {}
