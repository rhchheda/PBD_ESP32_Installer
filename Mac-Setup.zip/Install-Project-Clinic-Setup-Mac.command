#!/bin/bash
# ============================================================
# Project Clinic, KLE-C-SHInE - Student Machine Setup - macOS
# ------------------------------------------------------------
# Installs:
#   1. Arduino IDE (.dmg / .zip app bundle)
#   2. arduino-cli (headless - installs ESP32 board core)
#   3. ESP32 board package (target: DOIT ESP32 DEVKIT V1)
#   4. CP210x (Silicon Labs) USB-to-UART driver (.pkg)
#   5. CH210x (WCH CH340/CH341) USB-to-UART driver (.pkg)
# Shows progress via macOS native dialogs (osascript) and
# verifies each component before reporting success.
#
# Downloaded installers are cached under a persistent folder
# (see CACHE_DIR) so re-running this script does not
# re-download files already fetched.
#
# All URLs live in config.json next to this script.
# ============================================================

set -o pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
CONFIG_FILE="$SCRIPT_DIR/config.json"
CACHE_DIR="/Users/Shared/Project-Clinic-Setup/Cache"
WORK_DIR="/tmp/project-clinic-setup"
LOG_FILE="$WORK_DIR/install-log.txt"
START_TIME=$(date +%s)

mkdir -p "$WORK_DIR"
mkdir -p "$CACHE_DIR/ArduinoIDE" "$CACHE_DIR/ArduinoCLI" "$CACHE_DIR/Drivers" "$CACHE_DIR/Logo"

log() {
    echo "[$(date '+%H:%M:%S')] $1" | tee -a "$LOG_FILE"
}

notify() {
    # Non-blocking native macOS notification banner
    osascript -e "display notification \"$2\" with title \"$1\"" >/dev/null 2>&1
}

show_dialog() {
    local title="$1"
    local message="$2"
    local icon="$3"  # note | caution | stop
    osascript -e "display dialog \"$message\" with title \"$title\" buttons {\"OK\"} default button \"OK\" with icon $icon" >/dev/null 2>&1
}

require_sudo() {
    if [ "$EUID" -ne 0 ]; then
        log "Requesting administrator privileges..."
        exec sudo /bin/bash "$0" "$@"
    fi
}

# jq may not be present on a fresh Mac - fall back to python3 (always present on macOS)
json_get() {
    local key="$1"
    python3 -c "import json,sys; print(json.load(open('$CONFIG_FILE')).get('$key',''))"
}

# ---------- Cache-aware download ----------
# Usage: get_cached_file URL SUBFOLDER FILENAME
get_cached_file() {
    local url="$1" subfolder="$2" filename="$3"
    local dest="$CACHE_DIR/$subfolder/$filename"

    if [ -f "$dest" ] && [ -s "$dest" ]; then
        log "Using cached file: $dest"
        echo "$dest"
        return 0
    fi

    log "Downloading $url"
    curl -L --fail --progress-bar -o "$dest" "$url" >>"$LOG_FILE" 2>&1
    if [ $? -ne 0 ]; then
        rm -f "$dest"
        log "ERROR: download failed for $url"
        return 1
    fi
    log "Cached at $dest"
    echo "$dest"
    return 0
}

require_sudo "$@"

log "=== Project Clinic Setup (macOS) started ==="
INSTITUTE_NAME=$(json_get InstituteName)
LOGO_URL=$(json_get LogoUrl)
ARDUINO_IDE_URL=$(json_get ArduinoIdeUrl_Mac)
ARDUINO_CLI_URL=$(json_get ArduinoCliUrl_Mac)
CP210X_URL=$(json_get Cp210xDriverUrl_Mac)
CH210X_URL=$(json_get Ch210xDriverUrl_Mac)
ESP32_BOARDS_URL=$(json_get Esp32BoardsManagerUrl)
ESP32_PACKAGE_ID=$(json_get Esp32BoardPackageId)
ESP32_FQBN=$(json_get Esp32BoardFqbn)
SUCCESS_MSG=$(json_get SuccessMessage)

notify "$INSTITUTE_NAME Setup" "Starting installation - this window will update as each step completes."

STEP=0
TOTAL_STEPS=6
advance() {
    STEP=$((STEP + 1))
    local elapsed=$(( $(date +%s) - START_TIME ))
    log "Step $STEP/$TOTAL_STEPS complete. Elapsed: ${elapsed}s. $1"
    notify "$INSTITUTE_NAME Setup ($STEP/$TOTAL_STEPS)" "$1"
}

FAILURES=()

# ---------- Step 1: Arduino IDE ----------
log "=== Step 1: Arduino IDE ==="
ide_dmg=$(get_cached_file "$ARDUINO_IDE_URL" "ArduinoIDE" "arduino-ide.dmg") || FAILURES+=("Arduino IDE download")
if [ -n "$ide_dmg" ]; then
    MOUNT_POINT=$(hdiutil attach "$ide_dmg" -nobrowse | tail -1 | awk '{print $NF}')
    if [ -d "$MOUNT_POINT" ]; then
        APP_SRC=$(find "$MOUNT_POINT" -maxdepth 1 -name "*.app" | head -1)
        if [ -n "$APP_SRC" ]; then
            cp -R "$APP_SRC" /Applications/
            log "Arduino IDE copied to /Applications"
        else
            FAILURES+=("Arduino IDE .app not found in disk image")
        fi
        hdiutil detach "$MOUNT_POINT" -quiet
    else
        FAILURES+=("Arduino IDE disk image failed to mount")
    fi
fi
advance "Arduino IDE installed."

# ---------- Step 2: arduino-cli ----------
log "=== Step 2: arduino-cli ==="
cli_tar=$(get_cached_file "$ARDUINO_CLI_URL" "ArduinoCLI" "arduino-cli.tar.gz") || FAILURES+=("arduino-cli download")
CLI_DIR="$WORK_DIR/arduino-cli"
mkdir -p "$CLI_DIR"
if [ -n "$cli_tar" ]; then
    tar -xzf "$cli_tar" -C "$CLI_DIR"
fi
CLI_BIN="$CLI_DIR/arduino-cli"
chmod +x "$CLI_BIN" 2>/dev/null
advance "arduino-cli ready."

# ---------- Step 3: ESP32 board package ----------
log "=== Step 3: ESP32 board package (this is the big download) ==="
if [ -x "$CLI_BIN" ]; then
    "$CLI_BIN" config init --overwrite >>"$LOG_FILE" 2>&1
    "$CLI_BIN" config add board_manager.additional_urls "$ESP32_BOARDS_URL" >>"$LOG_FILE" 2>&1
    "$CLI_BIN" core update-index >>"$LOG_FILE" 2>&1
    "$CLI_BIN" core install "$ESP32_PACKAGE_ID" --skip-post-install >>"$LOG_FILE" 2>&1
else
    FAILURES+=("arduino-cli binary missing, ESP32 core not installed")
fi
advance "ESP32 board package installed."

# ---------- Step 4: CP210x driver ----------
log "=== Step 4: CP210x USB driver ==="
cp210x_pkg=$(get_cached_file "$CP210X_URL" "Drivers" "CP210xVCPDriver.pkg") || FAILURES+=("CP210x driver download")
if [ -n "$cp210x_pkg" ]; then
    installer -pkg "$cp210x_pkg" -target / >>"$LOG_FILE" 2>&1 || FAILURES+=("CP210x driver install failed")
fi
advance "CP210x driver installed."

# ---------- Step 5: CH210x driver ----------
log "=== Step 5: CH210x USB driver ==="
ch210x_pkg=$(get_cached_file "$CH210X_URL" "Drivers" "CH34xVCPDriver.pkg") || FAILURES+=("CH210x driver download")
if [ -n "$ch210x_pkg" ]; then
    installer -pkg "$ch210x_pkg" -target / >>"$LOG_FILE" 2>&1 || FAILURES+=("CH210x driver install failed")
fi
advance "CH210x driver installed."

# ---------- Step 6: Verification ----------
log "=== Step 6: Verifying installation ==="
[ -d "/Applications/Arduino IDE.app" ] || FAILURES+=("Arduino IDE not found in /Applications")

if [ -x "$CLI_BIN" ]; then
    "$CLI_BIN" core list 2>/dev/null | grep -q "esp32:esp32" || FAILURES+=("ESP32 board package not detected by arduino-cli")
    "$CLI_BIN" board listall 2>/dev/null | grep -qi "esp32doit-devkit-v1" || FAILURES+=("DOIT ESP32 DEVKIT V1 target not resolvable")
fi

# On modern macOS (11+), CP210x/CH340 use Apple's built-in AppleUSBVCP class
# driver / kernel extension approval flow rather than a classic kext list, so
# checking system_profiler for the driver name is unreliable across versions.
# The most robust portable check available without physical hardware attached
# is confirming the driver's system extension/profile was installed - a full
# check requires the actual board to be plugged in and enumerated in
# /dev/tty.* or /dev/cu.* (usually named usbserial or SLAB_USBtoUART).
if ls /dev/cu.usbserial* /dev/cu.SLAB_USBtoUART* >/dev/null 2>&1; then
    log "USB-serial device already enumerated: matches expected driver naming."
else
    log "NOTE: No ESP32 board currently plugged in - driver installation cannot be confirmed against real hardware until a board is connected. Ask the student to plug in their board and check System Settings > Privacy & Security if prompted to allow the driver's system extension."
fi

TOTAL_ELAPSED=$(( $(date +%s) - START_TIME ))
ELAPSED_STR="$((TOTAL_ELAPSED / 60))m $((TOTAL_ELAPSED % 60))s"
log "Total time taken: $ELAPSED_STR (actual figure depends on this machine's internet bandwidth)"

if [ ${#FAILURES[@]} -eq 0 ]; then
    log "=== All components installed and verified. System is ready to use. ==="
    show_dialog "$INSTITUTE_NAME - Setup Complete" "$SUCCESS_MSG\n\nTotal time taken: $ELAPSED_STR" "note"
else
    MISSING_LIST=$(printf '%s\n' "${FAILURES[@]}")
    log "=== Setup finished with issues: ${FAILURES[*]} ==="
    show_dialog "$INSTITUTE_NAME - Setup Incomplete" "Most components installed in $ELAPSED_STR, but these need attention:\n$MISSING_LIST\n\nPlease contact your lab instructor. Log: $LOG_FILE" "caution"
fi
